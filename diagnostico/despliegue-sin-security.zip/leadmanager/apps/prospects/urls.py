from django.urls import path

from .views import (
    get_dashboard,
    ConversationsView,
    ConversationView,
    StatisticsView,
    AgentsView,
    ChatbotAnalyzerView,
    KnowledgeView,
    ExportPreviewView,
    ExportDownloadView,
)


app_name = 'app_prospects'


urlpatterns = [
    path('dashboard/', get_dashboard, name='dashboard'),
    path('conversations/', ConversationsView.as_view(), name='conversations'),
    path('conversations/conversation/<int:conversation_id>/',
         ConversationView.as_view(), name='conversation'),
    path('export/preview/',
         ExportPreviewView.as_view(), name='export_preview'),
    path('export/download/',
         ExportDownloadView.as_view(), name='export_download'),
    path('statistics/', StatisticsView.as_view(), name='statistics'),
    path('agents/', AgentsView.as_view(), name='agents'),
    path('chatbot-analyzer/', ChatbotAnalyzerView.as_view(),
         name='chatbot_analyzer'),
    path('knowledge/', KnowledgeView.as_view(), name='knowledge'),
]
